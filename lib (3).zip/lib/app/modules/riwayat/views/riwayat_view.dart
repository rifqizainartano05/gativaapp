import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:fl_chart/fl_chart.dart';
import '../controllers/riwayat_controller.dart';
import '../../../widgets/custom_popup.dart';

class AppColors {
  static const primary = Color(0xFF2E7D32);
  static const textSecondary = Colors.grey;
  static const textMuted = Colors.black54;
  static const safe = Colors.green;
  static const warning = Colors.orange;
  static const danger = Colors.red;
}

class RiwayatView extends StatelessWidget {
  const RiwayatView({super.key});

  @override
  Widget build(BuildContext context) {
    final RiwayatController controller = Get.put(RiwayatController());

    String formatSimpleDate(DateTime date) {
      final months = [
        "Jan",
        "Feb",
        "Mar",
        "Apr",
        "Mei",
        "Jun",
        "Jul",
        "Ags",
        "Sep",
        "Okt",
        "Nov",
        "Des",
      ];
      return "${date.day} ${months[date.month - 1]} ${date.year}";
    }

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.light,
      ),
      child: Obx(() {
        bool isFromMission =
            Get.arguments is Map && Get.arguments['isFromMission'] == true;
        bool missionCompleted = controller.isMissionCompleted.value;
        bool canGoBack = !isFromMission || missionCompleted;

        return PopScope(
          canPop: canGoBack,
          onPopInvokedWithResult: (didPop, _) {
            if (didPop) return;
            if (!canGoBack) {
              CustomPopup.showWarning(
                'Perhatian',
                'Harap tunggu data termuat untuk menyelesaikan misi.',
              );
            }
          },
          child: Scaffold(
            backgroundColor: const Color(0xFFF4F6F8),
            body: Column(
              children: [
                // 1. HEADER (Green App Bar)
                Container(
                  width: double.infinity,
                  padding: EdgeInsets.only(
                    top: MediaQuery.of(context).padding.top + 20,
                    bottom: 20,
                    left: 24,
                    right: 24,
                  ),
                  decoration: const BoxDecoration(color: AppColors.primary),
                  child: Stack(
                    clipBehavior: Clip.none,
                    children: [
                      Positioned(
                        right: -30,
                        top: -40,
                        child: Icon(
                          Icons.access_time_rounded,
                          size: 150,
                          color: Colors.white.withValues(alpha: 0.1),
                        ),
                      ),
                      Row(
                        children: [
                          InkWell(
                            onTap: () {
                              if (!canGoBack) {
                                CustomPopup.showWarning(
                                  'Perhatian',
                                  'Harap tunggu data termuat untuk menyelesaikan misi.',
                                );
                              } else {
                                Get.back();
                              }
                            },
                            child: Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                color: Colors.white.withValues(alpha: 0.2),
                                shape: BoxShape.circle,
                              ),
                              child: const Icon(
                                Icons.arrow_back_ios_new_rounded,
                                color: Colors.white,
                                size: 20,
                              ),
                            ),
                          ),
                          const SizedBox(width: 16),
                          const Text(
                            'Riwayat',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                              fontSize: 22,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                // BODY SCROLLABLE
                Expanded(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.only(
                      left: 20,
                      right: 20,
                      top: 16,
                      bottom: 40,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // 1. SUMMARY CARD
                        Container(
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: Colors.grey.shade200),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withValues(alpha: 0.02),
                                blurRadius: 10,
                                offset: const Offset(0, 4),
                              ),
                            ],
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  const Text(
                                    'Total Asupan',
                                    style: TextStyle(
                                      fontSize: 12,
                                      color: AppColors.textSecondary,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Obx(() {
                                    if (controller.filteredLogs.isEmpty) {
                                      return const Text(
                                        '-',
                                        style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 16,
                                          color: AppColors.primary,
                                        ),
                                      );
                                    }
                                    double total = controller.getTotalIntake();
                                    return Text(
                                      '${NumberFormat.decimalPattern('id').format(total)} mg',
                                      style: const TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 16,
                                        color: AppColors.primary,
                                      ),
                                    );
                                  }),
                                ],
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 24),

                        // 2. CHART CARD
                        Container(
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: Colors.grey.shade200),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withValues(alpha: 0.02),
                                blurRadius: 10,
                                offset: const Offset(0, 4),
                              ),
                            ],
                          ),
                          child: Column(
                            children: [
                              SizedBox(
                                height: 220,
                                width: double.infinity,
                                child: Obx(() {
                                  if (controller.filteredLogs.isEmpty) {
                                    return const Center(
                                      child: Text(
                                        "Belum ada data",
                                        style: TextStyle(color: Colors.grey),
                                      ),
                                    );
                                  }
                                  final chartData = controller.getChartData();

                                  double maxHigh = controller
                                      .getAbsoluteMaxChartValue();
                                  // Pastikan maxHigh minimal mencakup semua data saat ini (untuk safety jika ada rounding error)
                                  for (int i = 0; i < chartData.length; i++) {
                                    double totalValue =
                                        chartData[i].amanValue +
                                        chartData[i].warningValue +
                                        chartData[i].bahayaValue;
                                    if (totalValue > maxHigh)
                                      maxHigh = totalValue;
                                  }

                                  double finalMaxY = maxHigh * 1.3;
                                  double finalMinY = -maxHigh * 0.15;

                                  double screenWidth =
                                      MediaQuery.of(context).size.width -
                                      64; // Asumsi margin kiri-kanan
                                  double minSpacing =
                                      55.0; // Jarak antar titik dikunci persis 55px
                                  int n = chartData.length;

                                  double requiredWidth = n > 1
                                      ? (n - 1) * minSpacing
                                      : minSpacing;
                                  double finalWidth;
                                  double finalMinX;
                                  double finalMaxX;

                                  if (requiredWidth < screenWidth) {
                                    // Jika data sedikit (misal 3 hari), isi sisa ruang kosong di sebelah kiri
                                    // agar grid abu-abu tetap penuh seukuran layar, tapi jarak antar titik tetap 55px.
                                    finalWidth = screenWidth;
                                    finalMaxX = n > 1
                                        ? (n - 1).toDouble()
                                        : 1.0;
                                    double visibleUnits =
                                        screenWidth / minSpacing;
                                    finalMinX = finalMaxX - visibleUnits;
                                  } else {
                                    // Jika data banyak (misal 7 hari ke atas), biarkan bisa di-scroll ke samping
                                    finalWidth = requiredWidth;
                                    finalMinX = 0;
                                    finalMaxX = n > 1
                                        ? (n - 1).toDouble()
                                        : 1.0;
                                  }

                                  List<FlSpot> spots = [];
                                  
                                  // 1. Tambahkan titik palsu di kiri (X < 0) agar grafik membentuk lereng gunung, bukan tebing terpotong vertikal.
                                  if (finalMinX < 0) {
                                    spots.add(FlSpot(finalMinX, 0));
                                  }
                                  spots.add(FlSpot(-1, 0));

                                  // 2. Data asli
                                  for (int i = 0; i < chartData.length; i++) {
                                    double totalValue = chartData[i].amanValue + chartData[i].warningValue + chartData[i].bahayaValue;
                                    spots.add(FlSpot(i.toDouble(), totalValue));
                                  }

                                  // 3. Tambahkan titik palsu di kanan (X >= n) agar lereng kanan juga melandai
                                  spots.add(FlSpot(n.toDouble(), 0));
                                  if (finalMaxX > n) {
                                    spots.add(FlSpot(finalMaxX, 0));
                                  }

                                  return Container(
                                    alignment: Alignment.centerRight,
                                    child: SingleChildScrollView(
                                      scrollDirection: Axis.horizontal,
                                      reverse:
                                          true, // Mulai dari kanan (terbaru)
                                      physics: const BouncingScrollPhysics(),
                                      child: Container(
                                        width:
                                            finalWidth +
                                            40, // +40 untuk ruang padding (kiri-kanan)
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: 20,
                                        ),
                                        child: LineChart(
                                          LineChartData(
                                            minX: finalMinX,
                                            maxX: finalMaxX,
                                            minY: finalMinY,
                                            maxY: finalMaxY,
                                            gridData: FlGridData(
                                              show: true,
                                              drawVerticalLine: false,
                                              horizontalInterval:
                                                  maxHigh / 4 == 0
                                                  ? 1
                                                  : maxHigh / 4,
                                              getDrawingHorizontalLine:
                                                  (value) => FlLine(
                                                    color: Colors.grey
                                                        .withValues(alpha: 0.2),
                                                    strokeWidth: 1,
                                                  ),
                                            ),
                                            titlesData: const FlTitlesData(
                                              show: false,
                                            ),
                                            borderData: FlBorderData(
                                              show: false,
                                            ),
                                            lineBarsData: [
                                              LineChartBarData(
                                                spots: spots,
                                                isCurved: true,
                                                curveSmoothness: 0.35,
                                                color: AppColors
                                                    .primary, // Warna garis hijau agak gelap
                                                barWidth: 4,
                                                isStrokeCapRound: true,
                                                dotData: FlDotData(
                                                  show: true,
                                                  checkToShowDot: (spot, barData) {
                                                    return spot.x >= 0 && spot.x < n; // Jangan tampilkan dot di titik palsu
                                                  },
                                                  getDotPainter:
                                                      (
                                                        spot,
                                                        percent,
                                                        barData,
                                                        index,
                                                      ) {
                                                        return FlDotCirclePainter(
                                                          radius: 4,
                                                          color: Colors.white,
                                                          strokeWidth: 2,
                                                          strokeColor:
                                                              AppColors.primary,
                                                        );
                                                      },
                                                ),
                                                belowBarData: BarAreaData(
                                                  show: true,
                                                  gradient: LinearGradient(
                                                    colors: [
                                                      AppColors.primary
                                                          .withValues(
                                                            alpha: 0.4,
                                                          ),
                                                      AppColors.primary
                                                          .withValues(
                                                            alpha: 0.0,
                                                          ),
                                                    ],
                                                    begin: Alignment.topCenter,
                                                    end: Alignment.bottomCenter,
                                                  ),
                                                ),
                                              ),
                                            ],
                                            lineTouchData: LineTouchData(
                                              enabled: true,
                                              touchTooltipData: LineTouchTooltipData(
                                                getTooltipColor: (spot) =>
                                                    Colors.blueGrey.shade800,
                                                getTooltipItems: (touchedSpots) {
                                                  return touchedSpots.map((
                                                    spot,
                                                  ) {
                                                    return LineTooltipItem(
                                                      '${spot.y.toInt()} mg',
                                                      const TextStyle(
                                                        color: Colors.white,
                                                        fontWeight:
                                                            FontWeight.bold,
                                                      ),
                                                    );
                                                  }).toList();
                                                },
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  );
                                }),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 24),

                        // 4. LIST CARD
                        Container(
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(24),
                            border: Border.all(color: Colors.grey.shade200),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withValues(alpha: 0.02),
                                blurRadius: 10,
                                offset: const Offset(0, 4),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // Header
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  const Text(
                                    'CATATAN ASUPAN NATRIUM',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 14,
                                      color: Colors.black87,
                                      letterSpacing: 0.5,
                                    ),
                                  ),
                                  InkWell(
                                    onTap: () => _showFilterBottomSheet(
                                      context,
                                      controller,
                                    ),
                                    child: Row(
                                      children: [
                                        const Text(
                                          'Filter',
                                          style: TextStyle(
                                            color: AppColors.primary,
                                            fontWeight: FontWeight.w600,
                                            fontSize: 14,
                                          ),
                                        ),
                                        const SizedBox(width: 4),
                                        const Icon(
                                          Icons.filter_list,
                                          color: AppColors.primary,
                                          size: 18,
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 20),

                              // Dynamic Log List
                              Obx(() {
                                final list = controller.filteredLogs;
                                if (list.isEmpty) {
                                  return const Center(
                                    child: Padding(
                                      padding: EdgeInsets.symmetric(
                                        vertical: 40.0,
                                      ),
                                      child: Text(
                                        'Belum ada catatan asupan untuk periode ini.',
                                        style: TextStyle(
                                          color: AppColors.textMuted,
                                          fontStyle: FontStyle.italic,
                                        ),
                                      ),
                                    ),
                                  );
                                }

                                return ListView.separated(
                                  padding: EdgeInsets.zero,
                                  shrinkWrap: true,
                                  physics: const NeverScrollableScrollPhysics(),
                                  itemCount: list.length,
                                  separatorBuilder: (context, index) =>
                                      const SizedBox(height: 12),
                                  itemBuilder: (context, idx) {
                                    final log = list[idx];

                                    Color densityColor = AppColors.safe;
                                    if (log.type == 'makanan') {
                                      densityColor = log.amount >= 1000
                                          ? AppColors.danger
                                          : log.amount >= 600
                                          ? AppColors.warning
                                          : AppColors.safe;
                                    } else {
                                      densityColor = Colors.blue;
                                    }

                                    return Container(
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 16,
                                        vertical: 16,
                                      ),
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius: BorderRadius.circular(16),
                                        border: Border.all(
                                          color: Colors.grey.shade100,
                                        ),
                                      ),
                                      child: Row(
                                        children: [
                                          // Circular Icon
                                          Container(
                                            padding: const EdgeInsets.all(12),
                                            decoration: BoxDecoration(
                                              color: densityColor.withValues(alpha: 0.1),
                                              shape: BoxShape.circle,
                                            ),
                                            child: Icon(
                                              Icons.restaurant_rounded,
                                              color: densityColor,
                                              size: 20,
                                            ),
                                          ),
                                          const SizedBox(width: 14),

                                          // Details
                                          Expanded(
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  log.title,
                                                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: Colors.black87),
                                                ),
                                                const SizedBox(height: 4),
                                                Text(
                                                  log.type == 'makanan' ? 'Asupan Makanan' : 'Aktivitas Sehat',
                                                  style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
                                                  overflow: TextOverflow.ellipsis,
                                                ),
                                                const SizedBox(height: 2),
                                                Text(
                                                  formatSimpleDate(log.timestamp),
                                                  style: const TextStyle(fontSize: 11, color: AppColors.textMuted),
                                                ),
                                              ],
                                            ),
                                          ),
                                          
                                          // Total sodium badge
                                          Container(
                                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                                            decoration: BoxDecoration(
                                              color: densityColor.withValues(alpha: 0.1),
                                              borderRadius: BorderRadius.circular(20),
                                            ),
                                            child: Text(
                                              '${log.amount > 0 ? '+' : ''}${NumberFormat.decimalPattern('id').format(log.amount)} mg',
                                              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: densityColor),
                                            ),
                                          ),

                                        ],
                                      ),
                                    );
                                  },
                                );
                              }),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      }),
    );
  }

  void _showFilterBottomSheet(
    BuildContext context,
    RiwayatController controller,
  ) {
    RxString tempOption = controller.filterOption.value.obs;

    showModalBottomSheet(
      context: context,
      isScrollControlled: false,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return SafeArea(
          child: Container(
            padding: const EdgeInsets.only(top: 24, bottom: 16),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.zero,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'Filter Data',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      GestureDetector(
                        onTap: () => Get.back(),
                        child: const Icon(Icons.close),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                Flexible(
                  child: ListView.builder(
                    shrinkWrap: true,
                    physics: const BouncingScrollPhysics(),
                    itemCount: controller.filterOptionsList.length,
                    itemBuilder: (context, index) {
                      final option = controller.filterOptionsList[index];
                      return Obx(() {
                        final isSelected = tempOption.value == option;
                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // Top divider for the very first item
                            if (index == 0)
                              Divider(
                                height: 1,
                                thickness: 1,
                                color: Colors.grey.shade200,
                              ),
                            ListTile(
                              contentPadding: const EdgeInsets.symmetric(
                                horizontal: 24,
                              ),
                              title: Text(
                                option,
                                style: TextStyle(
                                  fontWeight: FontWeight.normal,
                                  color: isSelected
                                      ? AppColors.primary
                                      : Colors.black87,
                                ),
                              ),
                              trailing: Icon(
                                isSelected
                                    ? Icons.radio_button_checked
                                    : Icons.radio_button_unchecked,
                                color: isSelected
                                    ? AppColors.primary
                                    : Colors.grey.shade400,
                              ),
                              onTap: () {
                                if (option == "Atur Tanggal") {
                                  if (isSelected) {
                                    tempOption.value = ""; // Deselect
                                  } else {
                                    tempOption.value = option;
                                  }
                                } else {
                                  if (isSelected) {
                                    controller.setFilterOption(""); // Deselect
                                  } else {
                                    controller.setFilterOption(option);
                                  }
                                  Get.back();
                                }
                              },
                            ),
                            if (option == "Atur Tanggal" && isSelected)
                              Padding(
                                padding: const EdgeInsets.only(
                                  left: 24,
                                  right: 24,
                                  bottom: 16.0,
                                ),
                                child: Container(
                                  padding: const EdgeInsets.all(12),
                                  decoration: BoxDecoration(
                                    color: Colors.grey.shade50,
                                    borderRadius: BorderRadius.circular(12),
                                    border: Border.all(
                                      color: Colors.grey.shade200,
                                    ),
                                  ),
                                  child: Row(
                                    children: [
                                      Expanded(
                                        child: GestureDetector(
                                          onTap: () async {
                                            final DateTime? picked =
                                                await showDatePicker(
                                                  context: context,
                                                  initialDate:
                                                      controller
                                                          .customDateRange
                                                          .value
                                                          ?.start ??
                                                      DateTime.now(),
                                                  firstDate: DateTime(2000),
                                                  lastDate: DateTime.now(),
                                                );
                                            if (picked != null) {
                                              final end =
                                                  controller
                                                      .customDateRange
                                                      .value
                                                      ?.end ??
                                                  picked;
                                              controller.customDateRange.value =
                                                  DateTimeRange(
                                                    start: picked,
                                                    end: end.isBefore(picked)
                                                        ? picked
                                                        : end,
                                                  );
                                            }
                                          },
                                          child: Container(
                                            padding: const EdgeInsets.symmetric(
                                              vertical: 8,
                                              horizontal: 12,
                                            ),
                                            color: Colors.transparent,
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                const Text(
                                                  'Dari',
                                                  style: TextStyle(
                                                    fontSize: 12,
                                                    color: Colors.black54,
                                                  ),
                                                ),
                                                const SizedBox(height: 4),
                                                Text(
                                                  controller
                                                              .customDateRange
                                                              .value !=
                                                          null
                                                      ? "${controller.customDateRange.value!.start.day}/${controller.customDateRange.value!.start.month}/${controller.customDateRange.value!.start.year}"
                                                      : "Pilih",
                                                  style: const TextStyle(
                                                    fontWeight: FontWeight.bold,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        width: 1,
                                        height: 40,
                                        color: Colors.grey.shade300,
                                      ),
                                      Expanded(
                                        child: GestureDetector(
                                          onTap: () async {
                                            final DateTime? picked =
                                                await showDatePicker(
                                                  context: context,
                                                  initialDate:
                                                      controller
                                                          .customDateRange
                                                          .value
                                                          ?.end ??
                                                      DateTime.now(),
                                                  firstDate: DateTime(2000),
                                                  lastDate: DateTime.now(),
                                                );
                                            if (picked != null) {
                                              final start =
                                                  controller
                                                      .customDateRange
                                                      .value
                                                      ?.start ??
                                                  picked;
                                              controller.customDateRange.value =
                                                  DateTimeRange(
                                                    start: start.isAfter(picked)
                                                        ? picked
                                                        : start,
                                                    end: picked,
                                                  );
                                            }
                                          },
                                          child: Container(
                                            padding: const EdgeInsets.symmetric(
                                              vertical: 8,
                                              horizontal: 12,
                                            ),
                                            color: Colors.transparent,
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                const Text(
                                                  'Sampai',
                                                  style: TextStyle(
                                                    fontSize: 12,
                                                    color: Colors.black54,
                                                  ),
                                                ),
                                                const SizedBox(height: 4),
                                                Text(
                                                  controller
                                                              .customDateRange
                                                              .value !=
                                                          null
                                                      ? "${controller.customDateRange.value!.end.day}/${controller.customDateRange.value!.end.month}/${controller.customDateRange.value!.end.year}"
                                                      : "Pilih",
                                                  style: const TextStyle(
                                                    fontWeight: FontWeight.bold,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            Divider(
                              height: 1,
                              thickness: 1,
                              color: Colors.grey.shade200,
                            ),
                          ],
                        );
                      });
                    },
                  ),
                ),
                Obx(() {
                  if (tempOption.value == "Atur Tanggal") {
                    return Padding(
                      padding: const EdgeInsets.only(
                        top: 16.0,
                        left: 24,
                        right: 24,
                      ),
                      child: SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          onPressed: () {
                            controller.setFilterOption(tempOption.value);
                            Get.back();
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppColors.primary,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                            padding: const EdgeInsets.symmetric(vertical: 14),
                          ),
                          child: const Text(
                            "Terapkan",
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    );
                  }
                  return const SizedBox.shrink();
                }),
              ],
            ),
          ),
        );
      },
    );
  }
}
