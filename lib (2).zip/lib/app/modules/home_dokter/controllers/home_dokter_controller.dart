import 'dart:convert';
import 'dart:typed_data';
import 'package:get/get.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../../../services/auth_service.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

class HomeDokterController extends GetxController {

  final RxString dokterName = 'Tenaga Kesehatan'.obs;
  final RxString strNumber = 'Menunggu Data...'.obs;
  final RxString photoBase64 = ''.obs;
  final Rx<Uint8List?> imageBytes = Rx<Uint8List?>(null);
  final RxInt totalPatients = 0.obs;
  final isLoading = true.obs;

  final RxInt patuhCount = 0.obs;
  final RxInt kurangPatuhCount = 0.obs;
  final RxInt tidakPatuhCount = 0.obs;

  @override
  void onInit() {
    super.onInit();
    
    ever(photoBase64, (String b64) {
      if (b64.isEmpty) {
        imageBytes.value = null;
        return;
      }
      try {
        if (b64.contains(',')) b64 = b64.split(',').last;
        b64 = b64.replaceAll(RegExp(r'\s+'), '');
        imageBytes.value = base64Decode(b64);
      } catch (e) {
        imageBytes.value = null;
      }
    });
    
    fetchDashboardData();
    Future.delayed(const Duration(seconds: 2), checkNotificationPermission);
  }

  Future<void> checkNotificationPermission() async {
    final status = await Permission.notification.status;
    if (!status.isGranted) {
      Get.dialog(
        AlertDialog(
          title: const Text("Izin Notifikasi", style: TextStyle(fontWeight: FontWeight.bold)),
          content: const Text("Untuk menerima peringatan pasien dan notifikasi penting, mohon izinkan notifikasi untuk aplikasi Gativa."),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          actions: [
            TextButton(
              onPressed: () => Get.back(),
              child: Text("Nanti", style: TextStyle(color: Colors.grey.shade600, fontWeight: FontWeight.bold)),
            ),
            ElevatedButton(
              onPressed: () async {
                Get.back();
                final result = await Permission.notification.request();
                if (result.isPermanentlyDenied) {
                  openAppSettings();
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF2E7D32),
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              child: const Text("Izinkan", style: TextStyle(fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      );
    }
  }

  Future<void> fetchDashboardData() async {
    isLoading.value = true;
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        Get.find<AuthService>()
            .getUserReference(user.uid)
            .snapshots()
            .listen((dokterDoc) {
          if (dokterDoc.exists) {
            final data = dokterDoc.data() as Map<String, dynamic>?;
            dokterName.value = data?['name'] ?? 'Tenaga Kesehatan';
            strNumber.value = data?['str'] ?? data?['strNumber'] ?? '-';
            photoBase64.value = data?['photo64'] ?? '';
          }
        });

        // Hitung total pasien di subcollection mobile/roles/pasien
        FirebaseFirestore.instance
            .collection('mobile')
            .doc('roles')
            .collection('pasien')
            .snapshots()
            .listen((pasienSnapshot) {
          final total = pasienSnapshot.docs.length;
          totalPatients.value = total;

          int patuh = 0;
          int kurangPatuh = 0;
          int tidakPatuh = 0;

          for (var doc in pasienSnapshot.docs) {
            final data = doc.data();
            double limit = (data['dailyLimit'] ?? 2000.0).toDouble();
            if (limit == 0) limit = 2000.0;
            double natrium = (data['natrium'] ?? data['sodium'] ?? data['totalNatrium'] ?? 0.0).toDouble();
            
            double ratio = natrium / limit;
            
            if (ratio < 0.6) {
              patuh++;
            } else if (ratio < 0.9) {
              kurangPatuh++;
            } else {
              tidakPatuh++;
            }
          }

          patuhCount.value = patuh;
          kurangPatuhCount.value = kurangPatuh;
          tidakPatuhCount.value = tidakPatuh;
          
          isLoading.value = false;
        });
      } else {
        isLoading.value = false;
      }
    } catch (e) {
      isLoading.value = false;
    }
  }
}
