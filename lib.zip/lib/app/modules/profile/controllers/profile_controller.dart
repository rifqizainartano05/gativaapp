import '../../../widgets/custom_popup.dart';
import 'dart:convert';
import 'dart:typed_data';
import 'package:permission_handler/permission_handler.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../../../routes/app_pages.dart';
import '../../../services/auth_service.dart';
import '../../../services/notification_service.dart';
import 'dart:async';

class ProfileController extends GetxController with WidgetsBindingObserver {
  final RxString name = "Pengguna".obs;
  final RxInt age = 28.obs;
  final RxString bloodPressure = "120/80".obs;
  final RxInt totalNatrium = 0.obs;

  final RxBool isNotificationEnabled = false.obs;
  final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
      FlutterLocalNotificationsPlugin();
  final RxString healthTargetText = "".obs;

  final RxString photoBase64 = "".obs;
  final Rx<Uint8List?> imageBytes = Rx<Uint8List?>(null);
  
  final RxString beratBadan = "Belum ada".obs;
  final RxString tinggiBadan = "Belum ada".obs;
  final RxString kondisiKesehatan = "Belum ada".obs;
  final RxString nakesName = "-".obs;
  final RxString nakesUid = "".obs;
  final RxString nakesPhotoBase64 = "".obs;
  final Rx<Uint8List?> nakesImageBytes = Rx<Uint8List?>(null);

  StreamSubscription? _chatSubscription;
  DateTime? _lastNotificationTime;

  @override
  void onClose() {
    WidgetsBinding.instance.removeObserver(this);
    _chatSubscription?.cancel();
    super.onClose();
  }


  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _initNotifications();
    }
  }

  @override
  void onInit() {
    super.onInit();
    WidgetsBinding.instance.addObserver(this);
    
    ever(photoBase64, (String b64) {
      if (b64.isEmpty) {
        imageBytes.value = null;
        return;
      }
      try {
        if (b64.contains(',')) b64 = b64.split(',').last;
        b64 = b64.replaceAll(RegExp(r'\s+'), '');
        imageBytes.value = base64Decode(b64);
      } catch (e) {
        imageBytes.value = null;
      }
    });

    ever(nakesPhotoBase64, (String b64) {
      if (b64.isEmpty) {
        nakesImageBytes.value = null;
        return;
      }
      try {
        if (b64.contains(',')) b64 = b64.split(',').last;
        b64 = b64.replaceAll(RegExp(r'\s+'), '');
        nakesImageBytes.value = base64Decode(b64);
      } catch (e) {
        nakesImageBytes.value = null;
      }
    });
    
    _initNotifications();
    fetchUserData();
  }

  void fetchUserData() {
    User? user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      Get.find<AuthService>().getUserReference(user.uid).snapshots().listen((
        doc,
      ) {
        if (doc.exists) {
          final data = doc.data() as Map<String, dynamic>;
          name.value = data['name'] ?? data['nama'] ?? user.displayName ?? "Pengguna";
          age.value = data['age'] ?? data['usia'] ?? 28;
          photoBase64.value = data['photoBase64'] ?? '';
          beratBadan.value = data['berat_badan']?.toString() ?? 'Belum ada';
          tinggiBadan.value = data['tinggi_badan']?.toString() ?? 'Belum ada';
          kondisiKesehatan.value = data['kondisi'] ?? data['kondisi_kesehatan'] ?? 'Belum ada';
          nakesName.value = data['nakesName'] ?? '-';
          
          if (data['nakesUid'] != null && data['nakesUid'].toString().isNotEmpty) {
            nakesUid.value = data['nakesUid'];
            _fetchNakesPhoto(nakesUid.value);
            
            // Re-initiate listening if notification is already enabled
            if (isNotificationEnabled.value) {
              _listenToIncomingChats();
            }
          }

          // Format dailyLimit to int string correctly
          if (data['dailyLimit'] != null && data['dailyLimit'] != 0) {
            double limit = (data['dailyLimit'] as num).toDouble();
            healthTargetText.value = limit.toInt().toString();
          } else {
            healthTargetText.value = calculateDailyLimit(age.value, kondisiKesehatan.value).toInt().toString();
          }

          bloodPressure.value = data['tekanan_darah'] ?? data['tensi'] ?? "Belum ada";
        }
      });

      Get.find<AuthService>()
          .getUserReference(user.uid)
          .collection('label gizi makanan')
          .snapshots()
          .listen((snapshot) {
        double dailyTotal = 0.0;
        final now = DateTime.now();
        for (var doc in snapshot.docs) {
          final data = doc.data();
          DateTime? docDate = (data['created_at'] as Timestamp?)?.toDate() ?? (data['timestamp'] as Timestamp?)?.toDate();
          if (docDate != null && docDate.year == now.year && docDate.month == now.month && docDate.day == now.day) {
            dailyTotal += ((data['natrium'] ?? data['sodium'] ?? data['amount'] ?? 0) as num).toDouble();
          }
        }
        totalNatrium.value = dailyTotal.toInt();
      },
    );
    }
  }

  void _listenToIncomingChats() {
    User? user = FirebaseAuth.instance.currentUser;
    if (user == null || nakesUid.value.isEmpty) return;

    _chatSubscription?.cancel();
    _lastNotificationTime = DateTime.now(); 

    _chatSubscription = Get.find<AuthService>()
        .getUserReference(user.uid)
        .collection('chats')
        .doc(nakesUid.value)
        .collection('messages')
        .orderBy('timestamp', descending: true)
        .limit(1)
        .snapshots()
        .listen((snapshot) {
      if (snapshot.docs.isNotEmpty) {
        final data = snapshot.docs.first.data();
        final senderRole = data['senderRole'] ?? '';
        final timestamp = (data['timestamp'] as Timestamp?)?.toDate();
        
        if (senderRole == 'nakes' && timestamp != null && timestamp.isAfter(_lastNotificationTime!)) {
           _lastNotificationTime = DateTime.now();
           NotificationService.showNotification(
             id: 101, 
             title: "Pesan Baru dari ${nakesName.value}", 
             body: data['text'] ?? "Ada pesan masuk!"
           );
        }
      }
    });
  }

  Future<void> _fetchNakesPhoto(String uid) async {
    try {
      final doc = await FirebaseFirestore.instance.collection('mobile').doc('roles').collection('tenaga_kesehatan').doc(uid).get();
      if (doc.exists) {
        final data = doc.data();
        if (data != null) {
          nakesPhotoBase64.value = data['photoBase64'] ?? '';
          nakesName.value = data['name'] ?? data['nama'] ?? nakesName.value;
        }
      }
    } catch (e) {
      // ignore
    }
  }



  Future<void> resetDataNatrium() async {
    try {
      User? user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        final docs = await Get.find<AuthService>()
            .getUserReference(user.uid)
            .collection('label gizi makanan')
            .get();
        for (var doc in docs.docs) {
          await doc.reference.delete();
        }
        
        await Get.find<AuthService>()
            .getUserReference(user.uid)
            .update({'totalNatrium': 0});

        Get.snackbar("Berhasil", "Semua data natrium telah dihapus.",
            backgroundColor: Colors.green.shade100, colorText: Colors.green.shade800);
      }
    } catch (e) {
      Get.snackbar("Gagal", "Gagal menghapus data: $e",
          backgroundColor: Colors.red.shade100, colorText: Colors.red.shade800);
    }
  }

  void _initNotifications() async {
    const AndroidInitializationSettings initializationSettingsAndroid =
        AndroidInitializationSettings('@mipmap/ic_launcher');
    const InitializationSettings initializationSettings =
        InitializationSettings(android: initializationSettingsAndroid);
    await flutterLocalNotificationsPlugin.initialize(
      settings: initializationSettings,
    );
    
    // Cek status izin notifikasi di OS
    final status = await Permission.notification.status;
    if (status.isGranted) {
      isNotificationEnabled.value = true;
      _listenToIncomingChats();
    } else {
      isNotificationEnabled.value = false;
    }
  }

  Future<void> toggleNotification(bool value) async {
    final status = await Permission.notification.status;
    if (status.isGranted) {
      CustomPopup.showWarning("Pengaturan Perangkat", "Notifikasi saat ini diaktifkan oleh sistem. Untuk mematikannya, silakan ubah di Pengaturan HP Anda.");
      Future.delayed(const Duration(seconds: 2), () {
        openAppSettings();
      });
      _initNotifications(); // Re-check
    } else {
      final result = await Permission.notification.request();
      if (result.isGranted) {
        isNotificationEnabled.value = true;
        _listenToIncomingChats();
        CustomPopup.showSuccess("Sukses", "Notifikasi berhasil diaktifkan!");
        } else {
        CustomPopup.showWarning("Pengaturan Perangkat", "Notifikasi dimatikan oleh sistem. Untuk menghidupkannya, silakan ubah di Pengaturan HP Anda.");
        Future.delayed(const Duration(seconds: 2), () {
          openAppSettings();
        });
        isNotificationEnabled.value = false;
      }
    }
  }

  void _showNotificationDialog({
    required bool isActive,
    required String title,
    required String message,
    required IconData icon,
    required Color color,
  }) {
    Get.dialog(
      Dialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24),
        ),
        backgroundColor: Colors.white,
        elevation: 10,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(24),
          child: Stack(
            children: [
              Positioned(
                right: -40,
                bottom: -20,
                child: Icon(
                  icon,
                  size: 200,
                  color: color.withOpacity(0.05),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: color.withOpacity(0.1),
                        shape: BoxShape.circle,
                      ),
                      child: Icon(
                        icon,
                        color: color,
                        size: 48,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      title,
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: color,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      message,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        fontSize: 14,
                        color: Colors.black87,
                        height: 1.5,
                      ),
                    ),
                    const SizedBox(height: 24),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: () => Get.back(),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: color,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          elevation: 0,
                        ),
                        child: const Text(
                          "Mengerti",
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _evaluateSodiumAndNotify() async {
    final double limit = double.tryParse(healthTargetText.value) ?? 2000.0;
    final int current = totalNatrium.value;

    String title = '';
    String body = '';

    if (current >= limit) {
      title = '⚠️ Batas Terlampaui!';
      body =
          'Asupan natrium Anda ($current mg) telah melebihi batas harian (${limit.toInt()} mg). Kurangi makanan asin!';
    } else if (current >= limit * 0.8) {
      title = 'Perhatian! Hampir Mencapai Batas';
      body =
          'Asupan natrium ($current mg) mendekati batas harian (${limit.toInt()} mg).';
    } else {
      title = 'Status Natrium Aman ✅';
      body =
          'Asupan Anda ($current mg) masih dalam batas aman hari ini (${limit.toInt()} mg).';
    }

    const AndroidNotificationDetails androidPlatformChannelSpecifics =
        AndroidNotificationDetails(
          'gativa_limit_channel',
          'Peringatan Batas Natrium',
          channelDescription: 'Notifikasi jika melewati batas asupan',
          importance: Importance.max,
          priority: Priority.high,
          ticker: 'ticker',
        );
    const NotificationDetails platformChannelSpecifics = NotificationDetails(
      android: androidPlatformChannelSpecifics,
    );

    await flutterLocalNotificationsPlugin.show(
      id: 0,
      title: title,
      body: body,
      notificationDetails: platformChannelSpecifics,
    );
  }

  void showNakesDialog() {
    bool isConnected = nakesName.value != '-' && nakesName.value.isNotEmpty;
    String nameToShow = isConnected ? nakesName.value : 'Belum Terhubung';
    
    Get.dialog(
      Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        backgroundColor: Colors.white,
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Obx(() => Container(
                width: 80,
                height: 80,
                decoration: BoxDecoration(
                  color: const Color(0xFF2E7D32).withOpacity(0.1),
                  shape: BoxShape.circle,
                  image: nakesImageBytes.value != null
                      ? DecorationImage(
                          image: MemoryImage(nakesImageBytes.value!),
                          fit: BoxFit.cover,
                        )
                      : null,
                ),
                child: nakesImageBytes.value == null
                    ? const Icon(
                        Icons.medical_services_rounded,
                        size: 40,
                        color: Color(0xFF2E7D32),
                      )
                    : null,
              )),
              const SizedBox(height: 16),
              const Text(
                'Tenaga Kesehatan Anda',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                  color: Colors.grey,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                nameToShow,
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),
              if (!isConnected) ...[
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: () {
                      Get.back();
                      Get.toNamed(Routes.SCAN_TENAGA_KESEHATAN_AKSES);
                    },
                    icon: const Icon(Icons.qr_code_scanner_rounded, color: Colors.white),
                    label: const Text(
                      'Scan Akses',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF2E7D32),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton(
                    onPressed: () => Get.back(),
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: Colors.grey),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                    child: const Text(
                      'Tutup',
                      style: TextStyle(
                        color: Colors.black54,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ] else ...[
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () => Get.back(),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF2E7D32),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                    child: const Text(
                      'Tutup',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }



  // Dialog Ekspor
  void showExportDialog() {
    Get.dialog(
      Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        backgroundColor: Colors.white,
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Expanded(
                    child: Text(
                      "Ekspor Laporan Medis",
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close, color: Colors.grey),
                    onPressed: () => Get.back(),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              const Text(
                "Pilih rentang tanggal untuk laporan tenaga kesehatan Anda.",
                style: TextStyle(color: Colors.grey, fontSize: 13),
              ),
              const SizedBox(height: 24),
              ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF2E7D32),
                  minimumSize: const Size(double.infinity, 54),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  elevation: 0,
                ),
                icon: const Icon(Icons.date_range_rounded, color: Colors.white),
                label: const Text(
                  "Pilih Rentang Tanggal",
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                  ),
                ),
                onPressed: () async {
                  if (Get.context == null) return;

                  final DateTimeRange? picked = await showDateRangePicker(
                    context: Get.context!,
                    firstDate: DateTime(2020),
                    lastDate: DateTime(2030),
                    builder: (context, child) {
                      return Theme(
                        data: Theme.of(context).copyWith(
                          colorScheme: const ColorScheme.light(
                            primary: Color(0xFF2E7D32),
                            onPrimary: Colors.white,
                            onSurface: Colors.black,
                          ),
                        ),
                        child: child!,
                      );
                    },
                  );
                  if (picked != null) {
                    Get.back(); // Tutup dialog
                    _showDocumentChecklistDialog(); // Buka dialog checklist
                  }
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Dialog Checklist Dokumen Mengambang
  void _showDocumentChecklistDialog() {
    // State lokal untuk checkbox
    RxBool checkHarian = true.obs;
    RxBool checkGrafik = true.obs;
    RxBool checkKesimpulan = false.obs;

    Get.dialog(
      Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        backgroundColor: Colors.white,
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                "Dokumen Pendukung",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 8),
              const Text(
                "Pilih data yang ingin disertakan di dalam PDF:",
                style: TextStyle(color: Colors.grey, fontSize: 13),
              ),
              const SizedBox(height: 16),

              Obx(
                () => CheckboxListTile(
                  contentPadding: EdgeInsets.zero,
                  activeColor: const Color(0xFF2E7D32),
                  title: const Text(
                    "Data Asupan Harian",
                    style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                  ),
                  value: checkHarian.value,
                  onChanged: (val) => checkHarian.value = val ?? false,
                ),
              ),
              Obx(
                () => CheckboxListTile(
                  contentPadding: EdgeInsets.zero,
                  activeColor: const Color(0xFF2E7D32),
                  title: const Text(
                    "Grafik Tren Mingguan",
                    style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                  ),
                  value: checkGrafik.value,
                  onChanged: (val) => checkGrafik.value = val ?? false,
                ),
              ),
              Obx(
                () => CheckboxListTile(
                  contentPadding: EdgeInsets.zero,
                  activeColor: const Color(0xFF2E7D32),
                  title: const Text(
                    "Kesimpulan Sistem",
                    style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                  ),
                  value: checkKesimpulan.value,
                  onChanged: (val) => checkKesimpulan.value = val ?? false,
                ),
              ),

              const SizedBox(height: 24),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        side: const BorderSide(color: Colors.grey),
                      ),
                      onPressed: () => Get.back(),
                      child: const Text(
                        "Batal",
                        style: TextStyle(
                          color: Colors.black54,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF2E7D32),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        elevation: 0,
                      ),
                      onPressed: () {
                        Get.back();
                        Get.snackbar(
                          "Mengunduh",
                          "Laporan PDF sedang di-generate...",
                          backgroundColor: Colors.white,
                        );
                      },
                      child: const Text(
                        "Unduh",
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Dialog Target Kesehatan
  void showTargetDialog() {
    final TextEditingController inputController = TextEditingController();

    Get.dialog(
      Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        backgroundColor: Colors.white,
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: const Color(0xFF2E7D32).withOpacity(0.1),
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.monitor_weight_rounded,
                  color: Color(0xFF2E7D32),
                  size: 32,
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                "Target Kesehatan",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 8),
              const Text(
                "Berapa target berat badan dan batas natrium harian Anda?",
                style: TextStyle(color: Colors.grey, fontSize: 13),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),
              TextField(
                controller: inputController,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
                decoration: InputDecoration(
                  hintText: "Contoh: 65 kg / 1800 mg",
                  hintStyle: TextStyle(
                    color: Colors.grey.shade400,
                    fontWeight: FontWeight.normal,
                  ),
                  filled: true,
                  fillColor: Colors.grey.shade50,
                  contentPadding: const EdgeInsets.symmetric(
                    vertical: 16,
                    horizontal: 20,
                  ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16),
                    borderSide: BorderSide.none,
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16),
                    borderSide: const BorderSide(color: Color(0xFF2E7D32)),
                  ),
                ),
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF2E7D32),
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                    elevation: 0,
                  ),
                  onPressed: () {
                    if (inputController.text.isNotEmpty) {
                      healthTargetText.value = inputController.text;
                      Get.back();
                    }
                  },
                  child: const Text(
                    "Simpan Target",
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 15,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      barrierDismissible: true,
    );
  }

  void exportToPDF() {
    showExportDialog();
  }

  void confirmLogout() {
    Get.dialog(
      Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        backgroundColor: Colors.white,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(24),
          child: Stack(
            children: [
              // Watermark Icon
              Positioned(
                right: -30,
                bottom: -30,
                child: Icon(
                  Icons.shield_outlined,
                  size: 150,
                  color: const Color(0xFF2E7D32).withOpacity(0.05),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(24.0),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.red.withOpacity(0.1),
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: Colors.red.withOpacity(0.3),
                          width: 2,
                        ),
                      ),
                      child: const Icon(
                        Icons.logout_rounded,
                        color: Colors.red,
                        size: 36,
                      ),
                    ),
                    const SizedBox(height: 20),
                    const Text(
                      "Keluar Akun?",
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w900,
                        color: Colors.black87,
                      ),
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      "Apakah Anda yakin ingin keluar dari GATIVA? Anda harus login kembali untuk mengakses data kesehatan Anda.",
                      style: TextStyle(
                        color: Colors.grey,
                        fontSize: 14,
                        height: 1.5,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 30),
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton(
                            style: OutlinedButton.styleFrom(
                              padding: const EdgeInsets.symmetric(vertical: 14),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                              side: BorderSide(
                                color: Colors.grey.shade300,
                                width: 2,
                              ),
                            ),
                            onPressed: () => Get.back(),
                            child: const Text(
                              "Batal",
                              style: TextStyle(
                                color: Colors.black87,
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.red.shade600,
                              padding: const EdgeInsets.symmetric(vertical: 14),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                              elevation: 2,
                              shadowColor: Colors.red.withOpacity(0.5),
                            ),
                            onPressed: () async {
                              Get.back(); // tutup dialog
                              
                              // Set isOnline to false if user is a patient
                              final user = FirebaseAuth.instance.currentUser;
                              if (user != null) {
                                try {
                                  final roleSnapshot = await FirebaseFirestore.instance.collection('mobile').doc('roles').collection('pasien').doc(user.uid).get();
                                  if (roleSnapshot.exists) {
                                    await FirebaseFirestore.instance.collection('mobile').doc('roles').collection('pasien').doc(user.uid).update({
                                      'isOnline': false,
                                      'lastSeen': FieldValue.serverTimestamp(),
                                    });
                                  }
                                } catch (_) {}
                              }
                              
                              await FirebaseAuth.instance.signOut();
                              Get.offAllNamed(Routes.LOGIN);
                            },
                            child: const Text(
                              "Keluar",
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
      barrierDismissible: true,
    );
  }

  double calculateDailyLimit(int age, String condition) {
    String c = condition.trim().toLowerCase();
    if (age >= 5 && age <= 9) {
      if (c.contains('sehat')) return 1200;
      if (c.contains('hipertensi')) return 1200;
      if (c.contains('kardiovaskular')) return 1000;
      if (c.contains('jantung')) return 1000;
      if (c.contains('ginjal')) return 1000;
      if (c.contains('stroke')) return 0;
      return 1200;
    } else if (age >= 10 && age <= 17) {
      if (c.contains('sehat')) return 1500;
      if (c.contains('hipertensi')) return 1200;
      if (c.contains('kardiovaskular')) return 1000;
      if (c.contains('jantung')) return 1000;
      if (c.contains('ginjal')) return 1000;
      if (c.contains('stroke')) return 0;
      return 1500;
    } else if (age >= 18 && age <= 59) {
      if (c.contains('sehat')) return 2000;
      if (c.contains('hipertensi')) return 1500;
      if (c.contains('kardiovaskular')) return 1500;
      if (c.contains('jantung')) return 1500;
      if (c.contains('ginjal')) return 1500;
      if (c.contains('stroke')) return 1500;
      return 2000;
    } else if (age >= 60) {
      if (c.contains('sehat')) return 1200;
      if (c.contains('hipertensi')) return 1000;
      if (c.contains('kardiovaskular')) return 1200;
      if (c.contains('jantung')) return 1200;
      if (c.contains('ginjal')) return 1000;
      if (c.contains('stroke')) return 1000;
      if (c.contains('osteoporosis')) return 2300;
      return 1200;
    }
    return 2000;
  }
}
